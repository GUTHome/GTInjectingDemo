//
//  PHSubContainView.m
//  Test
//
//  Created by ty.Chen on 2019/12/27.
//  Copyright © 2019 ty.Chen. All rights reserved.
//

#import "PHSubContainView.h"
#import "UIResponder+SCRouter.h"
/// 这是注释啊 看的剑麻
NSString *const kSubContainViewRedBtnClick = @"kSubContainViewRedBtnClick";

@implementation PHSubContainView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        UIButton *redBtn = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 44, 44)];
        redBtn.backgroundColor = [UIColor redColor];
        [redBtn addTarget:self action:@selector(redBtnClick) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:redBtn];
    }
    return self;
}

- (void)redBtnClick {
    [self routerEventForName:kSubContainViewRedBtnClick paramaters:@[@{@"username": @"xxx"}, @"textxxx", @(5)]];
}

@end
