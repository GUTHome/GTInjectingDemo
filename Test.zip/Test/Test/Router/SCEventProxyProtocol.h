//
//  SCEventProxyProtocol.h
//  Test
//
//  Created by ty.Chen on 2019/12/27.
//  Copyright © 2019 ty.Chen. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol SCEventProxyProtocol <NSObject>

@optional

- (void)handleEventProxyForEvent:(NSString *)eventName paramaters:(NSArray *)paramaters;

@end
