//
//  ViewController.m
//  Test
//
//  Created by ty.Chen on 2019/12/27.
//  Copyright © 2019 ty.Chen. All rights reserved.
//

#import "ViewController.h"
#import "PHContainView.h"
#import "UIViewController+SCRouter.h"
#import "SCHomeEventProxy.h"

@interface ViewController ()

@property (nonatomic, strong) SCHomeEventProxy *routerEventProxy;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.eventProxy = self.routerEventProxy;
    
    PHContainView *containView = [[PHContainView alloc] initWithFrame:CGRectMake(50, 100, 300, 300)];
    containView.backgroundColor = [UIColor orangeColor];
    [self.view addSubview:containView];
}

- (SCHomeEventProxy *)routerEventProxy {
    if (!_routerEventProxy) {
        _routerEventProxy = [[SCHomeEventProxy alloc] init];
    }
    return _routerEventProxy;
}

@end
