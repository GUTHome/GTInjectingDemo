//
//  SCHomeEventProxy.m
//  Test
//
//  Created by ty.Chen on 2019/12/27.
//  Copyright © 2019 ty.Chen. All rights reserved.
//

#import "SCHomeEventProxy.h"

extern NSString *const kSubContainViewRedBtnClick;

@interface SCHomeEventProxy ()

@property (nonatomic, strong) NSDictionary<NSString *,NSInvocation *> *homeEventStrategy;

@end

@implementation SCHomeEventProxy

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.eventStrategy = self.homeEventStrategy;
    }
    return self;
}

- (void)subContainViewRedBtnClick:(NSDictionary *)info text:(NSString *)text intValueObjc:(NSNumber *)intValueObjc {
    NSLog(@"info: %@\ntext: %@\nintValueObjc: %@", info, text, intValueObjc);
}

#pragma mark - Layz Load

- (NSDictionary<NSString *,NSInvocation *> *)homeEventStrategy {
    if (!_homeEventStrategy) {
        _homeEventStrategy = @{
            kSubContainViewRedBtnClick: [self createInvocationForSelector:@selector(subContainViewRedBtnClick:text:intValueObjc:)]
        };
    }
    return _homeEventStrategy;
}

@end
