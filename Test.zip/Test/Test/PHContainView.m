//
//  PHContainView.m
//  Test
//
//  Created by ty.Chen on 2019/12/27.
//  Copyright © 2019 ty.Chen. All rights reserved.
//

#import "PHContainView.h"
#import "PHSubContainView.h"
#import "SCHomeEventProxy.h"
#import "UIView+SCRouter.h"

@interface PHContainView ()

@property (nonatomic, strong) SCHomeEventProxy *containViewEventProxy;

@end

@implementation PHContainView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        PHSubContainView *view = [[PHSubContainView alloc] initWithFrame:CGRectMake(0, 0, 100, 100)];
        view.backgroundColor = [UIColor purpleColor];
        [self addSubview:view];
        
        self.eventProxy = self.containViewEventProxy;
    }
    return self;
}

- (SCHomeEventProxy *)containViewEventProxy {
    if (!_containViewEventProxy) {
        _containViewEventProxy = [[SCHomeEventProxy alloc] init];
    }
    return _containViewEventProxy;
}

@end
